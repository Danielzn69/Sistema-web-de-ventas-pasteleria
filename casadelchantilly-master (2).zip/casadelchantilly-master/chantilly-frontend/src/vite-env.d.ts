﻿/// <reference types="vite/client" />
